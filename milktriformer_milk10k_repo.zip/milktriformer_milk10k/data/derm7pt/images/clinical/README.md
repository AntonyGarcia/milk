# derm7pt images

Store image files for `derm7pt` here. Medical images are not bundled with this repository.
