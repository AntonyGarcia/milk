# milk10k images

Store image files for `milk10k` here. Medical images are not bundled with this repository.
